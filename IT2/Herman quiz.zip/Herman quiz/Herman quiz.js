/* function check(){
document.getElementById("after_submit").style.visibility= "visible";
console.log("hei")
}*/